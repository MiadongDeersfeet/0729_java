package com.kh.chap06.run;

public class testignggsdg {

}

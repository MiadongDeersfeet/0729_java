package com.kh.chap06.controller;

public class Human {
	//�ʵ�
	private String name;
	
	public void hi() {
		
		System.out.println("�ȳ��ϼ���~!");
	}
	
	
}

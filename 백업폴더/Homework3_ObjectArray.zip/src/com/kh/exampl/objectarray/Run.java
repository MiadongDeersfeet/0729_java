package com.kh.exampl.objectarray;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package com.kh.person.run;

import com.kh.person.view.PersonMenu;

public class Run {

	public static void main(String[] args) {
		PersonMenu pm = new PersonMenu();
		
		pm.mainMenu();
		

	}

}

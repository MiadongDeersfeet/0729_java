package com.kh.person.controller;

import com.kh.person.model.vo.Employee;
import com.kh.person.model.vo.Student;

public class PersonController {
	// �ʵ�
	private Student[] s = new Student[3];
	private Employee[] e = new Employee[10];
	
	/*
	public PersonController() {
		s[0] = new Student();
		s[1] = new Student();		s[2] = new Student();
		
	}*/

	public int[] personCount(int[] arr) {
		int i = 0;
		for(i = 0; i < s.length; i++) {
			 
				
			}
		
	}
		
	public void insertStudent(String name, int age, double height, double weight, int grade, String major) {
		// ???
	}
	
	public Student printStudent() {
		// ���߿� �����ʿ�
	}
	
	public void insertEmployee(String name, int age, double height, double weight, int salary, String dept) {
		// ???
	}
	
	public Employee printEmployee() {
		return null; //????
	}
}
package com.kh.chap01;

import com.kh.chap01.condition.A_If;
import com.kh.chap01.condition.B_Else;
import com.kh.chap01.condition.C_Switch;

public class run {

	public static void main(String[] args) {
	
		A_If a = new A_If();
		//a.method1();
		//a.method2();
		//a.lunchMenu();
		//a.method3();
		//a.method4();
		
		B_Else b = new B_Else();
		//b.method1();
		//b.method2();
		//b.ageCheck();
		
		C_Switch c = new C_Switch();
		//c.method0();
		//c.method1();
		c.login();
		
		
	}
}

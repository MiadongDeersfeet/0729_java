package com.kh.chap02.run;

import com.kh.chap02.loop.A_For;
import com.kh.chap02.loop.B_While;

public class Run {

	public static void main(String[] args) {
		
		A_For a = new A_For();
		//a.method0();
		//a.method1();
		//a.method3();
		//a.gugudan();
		//a.method2();
		
		B_While b = new B_While();
		//b.method1();
		//b.method2();
		//b.method3();
		b.method4();
		
		
		
	}
}
